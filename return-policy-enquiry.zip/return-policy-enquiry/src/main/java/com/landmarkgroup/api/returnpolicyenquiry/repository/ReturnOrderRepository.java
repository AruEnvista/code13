package com.landmarkgroup.api.returnpolicyenquiry.repository;

/*public interface ReturnOrderRepository extends ReactiveMongoRepository<OmsReturnOrder, String>{
    Flux<OmsReturnOrder> findByReturnOrderNumber(String orderNumber) ;
}*/


