package com.landmarkgroup.api.returnpolicyenquiry.service;

import java.net.URISyntaxException;

public interface ServiceCommandInterface {

    Object Execute() throws URISyntaxException;
}
