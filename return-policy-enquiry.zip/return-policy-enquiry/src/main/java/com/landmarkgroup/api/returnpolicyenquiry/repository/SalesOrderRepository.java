package com.landmarkgroup.api.returnpolicyenquiry.repository;

import com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel.SalesOrderResponse;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Mono;
//import com.microsoft.azure.spring.data.cosmosdb.repository.ReactiveCosmosRepository;


public interface SalesOrderRepository extends ReactiveMongoRepository<SalesOrderResponse, String> {
    Mono<SalesOrderResponse> findByOrderNumber(String orderNumber);
}
