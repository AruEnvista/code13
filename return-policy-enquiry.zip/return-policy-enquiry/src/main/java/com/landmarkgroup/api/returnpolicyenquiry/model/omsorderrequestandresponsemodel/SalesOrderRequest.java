package com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

import javax.validation.constraints.NotNull;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class SalesOrderRequest {

    @JsonProperty("enterprise_code")
    private String enterpriseCode;

    @NotNull
    @JsonProperty("entry_type")
    private String entryType;

    @JsonProperty("document_type")
    private String documentType;

    @NonNull
    @JsonProperty("customer_order_number")
    private String customerOrderNumber;
}

