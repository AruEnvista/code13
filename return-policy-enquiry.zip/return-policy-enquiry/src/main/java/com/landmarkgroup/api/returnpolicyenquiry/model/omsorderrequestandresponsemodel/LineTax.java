package com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.mapping.Field;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class LineTax {
    @NonNull
    @Field("charge_category")
    private String chargeCategory;

    @NonNull
    @Field("charge_name")
    private String chargeName;

    @NonNull
    private double tax;

    @NonNull
    @Field("tax_name")
    private String taxName;

    @NonNull
    @Field("taxable_percentage")
    private double taxablePercentage;
}
